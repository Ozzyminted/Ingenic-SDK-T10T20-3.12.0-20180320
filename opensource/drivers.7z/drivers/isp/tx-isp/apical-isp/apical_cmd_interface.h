/*-----------------------------------------------------------------------------
	 This confidential and proprietary software/information may be used only
		as authorized by a licensing agreement from Apical Limited

				   (C) COPYRIGHT 2011 - 2015 Apical Limited
						  ALL RIGHTS RESERVED

	  The entire notice above must be reproduced on all authorized
	   copies and copies may only be made to the extent permitted
			 by a licensing agreement from Apical Limited.
-----------------------------------------------------------------------------*/

#ifndef __APICAL_CMD_INTERFACE_H__
#define __APICAL_CMD_INTERFACE_H__

void apical_cmd_process( void ) ;

#endif /* __APICAL_CMD_INTERFACE_H__ */
