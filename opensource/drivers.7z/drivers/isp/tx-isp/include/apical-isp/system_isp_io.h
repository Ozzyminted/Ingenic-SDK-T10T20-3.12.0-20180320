#if !defined(__SYSTEM_ISP_IO_H__)
#define __SYSTEM_ISP_IO_H__

#include "apical_types.h"
#include "system_io.h"
void system_reset_sensor(uint32_t mask);

#endif /* __SYSTEM_ISP_IO_H__ */
